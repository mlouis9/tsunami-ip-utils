"""
Placeholder
===========

This is a placeholder description
"""
from tsunami_ip_utils.viz import load_interactive_matrix_plot

# fig = load_interactive_matrix_plot('results/uncertainty_comparisons/MCT_comparisons_isotope_reaction.pkl')
# fig.show()

# fig = load_interactive_matrix_plot('results/uncertainty_comparisons/MCT_comparisons_isotope.pkl')
# fig.show()

fig = load_interactive_matrix_plot('results/matrix_plot_example.pkl')
fig.show()
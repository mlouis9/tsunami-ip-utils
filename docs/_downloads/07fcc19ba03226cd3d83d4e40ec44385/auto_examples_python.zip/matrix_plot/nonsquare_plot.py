"""
Non-Square Matrix Plots
=======================
"""
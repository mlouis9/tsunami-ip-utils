"""
Matrices With a Different Set of Applications and Experiments
=============================================================
"""
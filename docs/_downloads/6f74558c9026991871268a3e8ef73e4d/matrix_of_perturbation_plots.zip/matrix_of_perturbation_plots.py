"""
Matrix of Perturbation Plots
============================
This example demonstrates how to generate a matrix plot of perturbation plots for each application and experiment. This is useful
"""